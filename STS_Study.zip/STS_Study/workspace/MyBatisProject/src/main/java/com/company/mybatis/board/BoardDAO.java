package com.company.mybatis.board;

import java.util.List;

import org.apache.ibatis.session.SqlSession; //SqlSession interface | mybatis의 원조는 ibatis이기 때문이다.

import com.company.mybatis.util.SqlSessionFactoryBean;

public class BoardDAO {
	private SqlSession mybatis;

	//생성자
	public BoardDAO() {
		//mybatis 인스턴스 객체를 만드는게 생성자 안에서 할일 : mybatis를 통해서 crud 작업을 하겠다!
		/*
		 * SqlSessionFactoryBean클래스의 SqlSessionInstance를 호출해서 리턴하겠다. 
		 */
		mybatis = SqlSessionFactoryBean.getSqlSessionInstance();
	}
	//business component logic의 메소드들은 1~2줄이면 된다. DML 작업 2줄 : 테이블에 변화를 주고 / SELECT 작업 1줄 : 테이블에 있는걸 가져온다라는 의미
	public void insertBoard(BoardVO vo) { //BoardVO 객체 (vo)를 받아서 
		mybatis.insert("BoardDAO.insertBoard", vo);//insert("sql 문장",파라미터 vo)
		mybatis.commit();//commit을 주면 메모리에 있던 insert할 내용들이 디스크에 들어간다.DB에 실제 수록하라
	}
	//전체 게시글 목록 보기
	public List<BoardVO> getBoardList(BoardVO vo) {  
		return mybatis.selectList("BoardDAO.getBoardList", vo); //여러개를 select한것 selectList
	}
	
	//게시글 상세 보기
	public List<BoardVO> getBoard(BoardVO vo) {
		return mybatis.selectOne("BoardDAO.getBoard", vo); //조건에 맞는것만 가지고 온다. selectOne
	}
	//게시글 수정
	public void updateBoard(BoardVO vo) {
		mybatis.update("BoardDAO.updateBoard", vo);
		mybatis.commit();
	}
	//게시글 삭제
	public void deleteBoard(BoardVO vo) {
		mybatis.delete("BoardDAO.deleteBoard", vo);
		mybatis.commit();
	}
}
