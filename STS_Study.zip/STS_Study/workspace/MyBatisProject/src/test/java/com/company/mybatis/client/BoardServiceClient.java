package com.company.mybatis.client;

import java.util.List;

import com.company.mybatis.board.BoardDAO;
import com.company.mybatis.board.BoardVO;

public class BoardServiceClient {
	public static void main(String[] args) {
		//객체 생성
		BoardDAO boardDAO = new BoardDAO();
		BoardVO vo = new BoardVO();
		
		vo.setTitle("MyBatis 프레임워크 프로젝트 실습");
		vo.setWriter("이채우");
		vo.setContent("MyBatis 프레임워크는 개발자의 반복 작업을 획기적으로 줄여준다.");
		
		//BoardDAO클래스의 ~를 호출한다.
		boardDAO.insertBoard(vo);
		boardDAO.deleteBoard(vo);
		boardDAO.updateBoard(vo);
		
		//select
		List<BoardVO> boardList = boardDAO.getBoardList(vo);
		
		for(BoardVO board : boardList) {//확장된 for 문
			System.out.println("===> "+board.toString());
		}
	}
}
