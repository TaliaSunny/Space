package com.company.spring_mvc_board.board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.company.spring_mvc_board.board.BoardDO;
import com.company.spring_mvc_board.common.JDBCUtil;

public class BoardDAO {
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;

	public int getTotalRow(PageObject pageObject) {
		System.out.println("getTotalRow() 메소드 처리되었습니다.");

		int total = 0;
		String where = "";

		try {
			conn = JDBCUtil.getConnection();

			if(pageObject.getKey() != null && pageObject.getWord() != null) {
				where = "where " + pageObject.getKey() + " like '%" + pageObject.getWord() + "%'"; 
			}

			String sql = "select COUNT(*) from board " + where;
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			if(rs != null && rs.next()) {
				total = rs.getInt(1);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
		return total;
	} //end getTotalRow(PageObject pageObject) =======================================================

	//getBoardList() 메소드 구현
	public List<BoardDO> getBoardList(PageObject pageObject) {
		System.out.println("getBoardList() 메소드 처리되었습니다.");

		List<BoardDO> boardList = new ArrayList<BoardDO>();

		try {
			conn = JDBCUtil.getConnection();
			String where = "";

			if(pageObject.getKey() != null && pageObject.getWord() != null) {
				where = "where " + pageObject.getKey() + " like '%" + pageObject.getWord() + "%'"; 
			}
			/*String Condition_SQL = "select * from board " + where + " order by seq desc";
			Condition_SQL = "select ROWNUM AS rn, seq, title, writer, content, regdate, cnt from (" + Condition_SQL + ")";
			Condition_SQL = "select seq, title, writer, content, regdate, cnt from (" + Condition_SQL + ")"
					+ " where rn between ? and ?";*/

			String Condition_SQL 
			= "select * from (select ROWNUM AS rn, temp.* " + 
					"from (select * from board "+where+" order by seq desc)temp) " +
					"where rn between ? AND ?";
			pstmt = conn.prepareStatement(Condition_SQL);
			pstmt.setInt(1, pageObject.getStartRow());
			pstmt.setInt(2, pageObject.getEndRow());
			rs = pstmt.executeQuery();

			while(rs.next()) {
				BoardDO board = new BoardDO();

				board.setSeq(rs.getInt("SEQ"));
				board.setTitle(rs.getString("TITLE"));
				board.setWriter(rs.getString("WRITER"));
				board.setContent(rs.getString("CONTENT"));
				board.setRegdate(rs.getDate("REGDATE"));
				board.setCnt(rs.getInt("CNT"));

				boardList.add(board);
			}
		}catch(Exception e) {
			System.out.println("getBoardList() " + e);
		}finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
		return boardList;
	}//end getBoardList(PageObject pageObject) =======================================================
	//해당 게시글 상세보기 메소드 구현 

	public BoardDO getBoard(BoardDO boardDO) { 
		System.out.println("===> getBoard() 처리됨"); 
		BoardDO board = null; 
		try { 
			conn = JDBCUtil.getConnection(); 
			String UPDATE_CNT = "update board set cnt=cnt+1 where seq=?"; 
			pstmt = conn.prepareStatement(UPDATE_CNT); 
			pstmt.setInt(1, boardDO.getSeq()); 
			pstmt.execute(); 
			String BOARD_GET = "select * from board where seq=?"; 
			pstmt = conn.prepareStatement(BOARD_GET); 
			pstmt.setInt(1, boardDO.getSeq()); 
			rs = pstmt.executeQuery(); 
			if(rs.next()) { 
				board = new BoardDO(); 
				board.setSeq(rs.getInt("SEQ")); 
				board.setTitle(rs.getString("TITLE")); 
				board.setWriter(rs.getString("WRITER")); 
				board.setContent(rs.getString("CONTENT")); 
				board.setRegdate(rs.getDate("REGDATE")); 
				board.setCnt(rs.getInt("CNT")); 
			} 
		}catch(Exception e){ 
			e.printStackTrace(); 
		}finally { 
			JDBCUtil.close(rs, pstmt, conn); 
		} 
		return board; 
	}// End getBoard()========================================================================
}
