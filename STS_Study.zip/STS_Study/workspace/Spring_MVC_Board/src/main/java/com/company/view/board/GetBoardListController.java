package com.company.view.board;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.company.spring_mvc_board.board.BoardDAO;
import com.company.spring_mvc_board.board.BoardDO;
import com.company.spring_mvc_board.board.PageObject;

/*
 * [중요] 게시판에 '페이징 처리'까지 구현해야합니다~ *^^*
 */
public class GetBoardListController implements Controller{

	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		
		//1. 조건 검색 시 검색 대상(제목 or 작성자) 및 검색 내용 객체를 저장할 변수 설정
		String searchField = "";
		String searchText = "";
		
		//2. 사용자 입력 정보 추출
		if(request.getParameter("searchCondition") != "" &&
				request.getParameter("searchKeyword") != "") {
			searchField = request.getParameter("searchCondition");
			searchText = request.getParameter("searchKeyword");
		}
		
		
		//3. 페이징 처리와 관련된 소스
		String pageStr = request.getParameter("page");
		if(pageStr == null || pageStr.equals("")) pageStr = "1";
		int page = Integer.parseInt(pageStr);
		
		String perPageNumStr = request.getParameter("perPageNum");
		
		if(perPageNumStr == null || perPageNumStr.equals("")) perPageNumStr = "10";
		int perPageNum = Integer.parseInt(perPageNumStr);
		
		PageObject pageObject = new PageObject(page, perPageNum);
		
		BoardDO boardDO = new BoardDO();
		BoardDAO boardDAO = new BoardDAO();
		
		pageObject.setKey(searchField); 	//제목 or 작성자
		pageObject.setWord(searchText); 	//검색 내용
		
		pageObject.setTotalRow(boardDAO.getTotalRow(pageObject));
		
		List<BoardDO> boardList = boardDAO.getBoardList(pageObject);
		
		//4. 포워딩(응답)
		ModelAndView mav = new ModelAndView();
		mav.addObject("boardList", boardList);	//Model 정보 저장
		mav.addObject("pageObject", pageObject);
		mav.addObject("boardDAO", boardDAO);
		System.out.println("검색이 완료되었습니다.");
		
		mav.setViewName("getBoardList");		//View 정보 저장
		System.out.println("전체목록보기 화면이 출력되었습니다.");
		return mav;
		
		
		
		

	}

}
