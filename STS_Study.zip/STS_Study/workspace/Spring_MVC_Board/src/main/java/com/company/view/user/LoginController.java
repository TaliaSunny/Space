package com.company.view.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.company.spring_mvc_board.user.UserDAO;
import com.company.spring_mvc_board.user.UserDO;

public class LoginController implements Controller{

	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("로그인 처리 되었습니다.");
		
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		
		UserDO userDO = new UserDO();
		userDO.setId(id);
		userDO.setPassword(password);
		
		UserDAO userDAO = new UserDAO();
		UserDO user = userDAO.getUser(userDO);
		
		//포워딩(응답)
		ModelAndView mav = new ModelAndView();
		
		if(user != null) {	//인증 성공 시!!
			HttpSession session = request.getSession();
			session.setAttribute("idkey", id);
			//mav.addObject("idkey", id);	//Model 정보 저장
			//System.out.println("로그인 인증 성공!!");
			mav.setViewName("redirect:getBoardList.do");	//view 정보 저장
		}else {		//인증 실패 시
			mav.setViewName("redirect:login.jsp");
			System.out.println("로그인 인증 실패입니다.");
		}
		return mav;
		
	}

}
