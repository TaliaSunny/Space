package com.company.spring_mvc_board.board;

import java.net.URLEncoder;

public class PageObject {
	//게시판의 페이징 관련 멤버 필드(변수)
	private int page;				//현재 페이지
	private int perPageNum;			//한 페이지 당 게시글 수 => 10개
	private int startRow;			//해당 페이지의 시작 행
	private int endRow;				//해당 페이지의 마지막 행
	
	private int perGrouppageNum;	//페이징 블록의 개수 => 10개
	private int startPage;			//시작 페이지
	private int endPage;			//마지막 페이지
	private int totalPage;			//총 페이지 개수
	private int totalRow;			//총 게시글 개수
	
	private String key;				//조건 검색 시 '제목' or '작성자'
	private String word;			//검색 단어 
	
	private String period;			//기간
	private String accepter;		//승낙자
	
	//생성자
	//					 현재 페이지     한 페이지 당 게시글 개수
	public PageObject(int page, int perPageNum) {
		this.page = page;				//멤버 변수 초기화
		this.perPageNum = perPageNum;	//멤버 변수 초기화
		
		startRow = (page-1) * perPageNum+1;	//시작번호 = (현재페이지-1) * 페이지당 게시글 수+1
		endRow = startRow + perPageNum-1;	//끝번호 = 시작번호 + 페이지당 게시글 수-1
		
		perGrouppageNum = 10;	//페이징 블록의 개수
	}
	//기본 생성자
	public PageObject() {
		this.endPage=1;
		this.perPageNum=10;
		this.period="pre";
	}
	
	//getter setter 메소드
	public int getPage() {return page;}
	public void setPage(int page) {this.page = page;}
	
	public int getPerPageNum() {return perPageNum;}
	public void setPerPageNum(int perPageNum) {this.perPageNum = perPageNum;}
	
	public int getStartRow() {return startRow;}
	public void setStartRow(int startRow) {this.startRow = startRow;}
	
	public int getEndRow() {return endRow;}
	public void setEndRow(int endRow) {this.endRow = endRow;}
	
	public int getPerGrouppageNum() {return perGrouppageNum;}
	public void setPerGrouppageNum(int perGrouppageNum) {this.perGrouppageNum = perGrouppageNum;}
	
	public int getStartPage() {return startPage;}
	public void setStartPage(int startPage) {this.startPage = startPage;}
	
	public int getEndPage() {return endPage;}
	public void setEndPage(int endPage) {this.endPage = endPage;}
	
	public int getTotalPage() {return totalPage;}
	public void setTotalPage(int totalPage) {this.totalPage = totalPage;}
	
	public int getTotalRow() {return totalRow;}
	public void setTotalRow(int totalRow) {
		this.totalRow = totalRow;
		startRow = (page-1) * perPageNum+1;
		endRow = startRow + perPageNum-1;
		
		//총 페이지 = (총 게시글 개수-1)/한 페이지 당 게시글 개수+1
		totalPage = (totalRow-1)/perPageNum+1;
		//시작 페이지 = (현재 페이지-1)/페이징 블록의 개수 * 페이징 블록의 개수+1
		startPage = (page-1)/perGrouppageNum * perGrouppageNum+1;
		//마지막 페이지 = 시작 페이지 + 페이징 블록의 개수-1
		endPage = startPage + perGrouppageNum-1;
		
		if(endPage > totalPage) endPage = totalPage;
	}
	
	public String getKey() {return key;}
	public void setKey(String key) {this.key = key;}
	
	public String getWord() {return word;}
	public void setWord(String word) {this.word = word;}
	
	public String getPeriod() {return period;}
	public void setPeriod(String period) {this.period = period;}
	
	public String getAccepter() {return accepter;}
	public void setAccepter(String accepter) {this.accepter = accepter;}
	
	public String encoding(String word) {
		if(word == null || word.trim().length() == 0) return "";
		try {
			return URLEncoder.encode(word, "UTF-8");
		}catch(Exception e) {
			return "";
		}
	}
}
