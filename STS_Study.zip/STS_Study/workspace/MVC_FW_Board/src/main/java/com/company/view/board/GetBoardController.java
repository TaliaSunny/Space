package com.company.view.board; 
import javax.servlet.http.HttpServletRequest; 
import javax.servlet.http.HttpServletResponse; 
import javax.servlet.http.HttpSession; 
import com.company.mvc_fw_board.board.BoardDAO; 
import com.company.mvc_fw_board.board.BoardDO; 
import com.company.view.controller.Controller; 

public class GetBoardController implements Controller { 
	@Override 
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) { 
		String seq= request.getParameter("seq"); 
		BoardDO boardDO = new BoardDO(); 
		boardDO.setSeq(Integer.parseInt(seq)); 
		BoardDAO boardDAO = new BoardDAO(); 
		BoardDO board = boardDAO.getBoard(boardDO); //getBoard()를 구현 하지 않았다!! BoardDAO.java 추가 작성 한 후에 주석을 풀어준다! 
		//board의 결과값은 session에 등록해야 getBoardList에 뿌려 줄 수 있다. 
		HttpSession session = request.getSession(); 
		session.setAttribute("board", board); //setAttribute은 void라서 반환 타입이 없다. 따라서 좌변이 존재 하지 않는다. board값을 "board"라는 이름으로 session에 등록(set)하겠다. 
		//포워딩 (forwording) - 응답 
		return("getBoard"); 
	} 
} 