package com.company.mvc_fw_board.board; 
import java.sql.Connection; 
import java.sql.PreparedStatement; 
import java.sql.ResultSet; 
import java.util.ArrayList; 
import java.util.List; 
import com.company.mvc_fw_board.board.BoardDO; 
import com.company.mvc_fw_board.common.JDBCUtil; 
public class BoardDAO { 
	private Connection conn = null; 
	private PreparedStatement pstmt = null; 
	private ResultSet rs = null; 
	public List<BoardDO> getBoardList(String searchField,String searchText){ //getBoardListController에서 호출했다. 
		System.out.println("===> getBoardList() 메소드 처리됨"); 
		//자료구조 => 가변 배열 10개 공간 확보 / 부족하면 10개씩 늘어난다. <BoardDO> 객체들만 담을 수 있는 객체 : generic 기능 -> 다른 객체가 들어오늘것을 막을 수 있다. 
		List<BoardDO> boardList = new ArrayList<BoardDO>();   
		try { 
			conn = JDBCUtil.getConnection(); 
			String where = ""; 
			if(searchField !=null && searchText !=null) { // 조건 검색인 경우 
				where = "where "+searchField+" like '%"+searchText+"%'"; 
			} 
			//하나의  SQL으로 => 전체 검색, 조건 검색을 할 수 있다. 전체 검색:  where = "" 조건 검색: where = "where "+searchField+" like '%"+searchText+"%'" 
			String SELECT_BOARD = "select * from board "+where+" order by seq desc"; 
			pstmt = conn.prepareStatement(SELECT_BOARD);  
			rs = pstmt.executeQuery(); //sql 문장을 처리한 결과를 rs객체에 할당했다. 
			while(rs.next()) { // 게시물이 있으면 true 없으면 false 
				BoardDO board = new BoardDO(); 
				board.setSeq(rs.getInt("SEQ"));//초기화 할 값을 rs에서 SEQ 끌어오면 된다. 
				board.setTitle(rs.getString("TITLE")); //DB에 들어갈때 컬럼이름이 대문자라서 "TITLE"을 대문자로 준다. 
				board.setWriter(rs.getString("WRITER")); 
				board.setContent(rs.getString("CONTENT")); 
				board.setRegdate(rs.getDate("REGDATE")); 
				board.setCnt(rs.getInt("CNT")); 
				//한 건을 boardList에 저장해라 , boardList의 객체 하나하나는 BoardDO객체이다. 
				boardList.add(board);//그 한건은 board가 가지고 있다.  
			} 
		}catch(Exception e) { 
			e.printStackTrace(); 
		}finally { 
			JDBCUtil.close(rs, pstmt, conn); 
		} 
		return boardList; // 최종게시글을 boardList에 가지고 있으니 boardList를 return 해줘라!!!
	}// end getBoardList()==================================================================== 
	//해당 게시글 상세보기 메소드 구현 
	public BoardDO getBoard(BoardDO boardDO) { 
		System.out.println("===> getBoard() 처리됨"); 
		BoardDO board = null; 
		try {
			conn = JDBCUtil.getConnection(); 
			String UPDATE_CNT = "update board set cnt=cnt+1 where seq=?"; 
			pstmt = conn.prepareStatement(UPDATE_CNT); 
			pstmt.setInt(1, boardDO.getSeq()); 
			pstmt.execute(); 
			String BOARD_GET = "select * from board where seq=?"; 
			pstmt = conn.prepareStatement(BOARD_GET); 
			pstmt.setInt(1, boardDO.getSeq()); 
			rs = pstmt.executeQuery(); 
			if(rs.next()) { 
				board = new BoardDO(); 
				board.setSeq(rs.getInt("SEQ")); 
				board.setTitle(rs.getString("TITLE")); 
				board.setWriter(rs.getString("WRITER")); 
				board.setContent(rs.getString("CONTENT")); 
				board.setRegdate(rs.getDate("REGDATE")); 
				board.setCnt(rs.getInt("CNT")); 
			} 
		}catch(Exception e){ 
			e.printStackTrace(); 
		}finally { 
			JDBCUtil.close(rs, pstmt, conn); 
		} 
		return board; 
	}// End getBoard()======================================================================== 
	//게시글 수정 처리 메소드 
	public void updateBoard(BoardDO boardDO) {//DispatcherServlet.java에서 path.equals("/updateBoard.do")부분의 boardDAO.updateBoard(boardDO); updateBoard()호출하면서 boardDO객체를 넘겨준다. 부분을 구현중이다. 
		System.out.println("===>JDBC로 updateBoard() 처리"); 
		try { 
			conn=JDBCUtil.getConnection(); 
			//SQL문장 만들기 
			String Board_UPDATE = "update board set title=?, content=? where seq=?";//제목과 내용이 수정되서 넘어올 수 있다. 조건 :게시글 번호에 넘어오는것을 수정 할때 
			pstmt = conn.prepareStatement(Board_UPDATE); 
			pstmt.setString(1,boardDO.getTitle());//첫번째 ? 값  : getter()메소드로 호출해서 가져온다. 
			pstmt.setString(2,boardDO.getContent()); 
			pstmt.setInt(3,boardDO.getSeq()); 
			pstmt.executeUpdate();//dml작업??? 
		}catch(Exception e) { 
			e.printStackTrace(); 
		}finally { 
			JDBCUtil.close(pstmt, conn);
		} 
	}// End updateBoard()======================================================================== 
	//새 게시글 등록 처리 메소드  
	public void insertBoard(BoardDO boardDO) { 
		System.out.println("===> JDBC로 insertBoard() 처리됨"); 
		try { 
			conn= JDBCUtil.getConnection(); 
			String BOARD_INSERT 
			="insert into board(seq,title,writer,content) values((select NVL(MAX(seq),0)+1 from board),?,?,?)"; 

			//title,writer,content는 boardDO객체에서  
			pstmt = conn.prepareStatement(BOARD_INSERT); 
			pstmt.setString(1,boardDO.getTitle()); 
			pstmt.setString(2, boardDO.getWriter()); 
			pstmt.setString(3, boardDO.getContent()); 
			pstmt.executeUpdate(); 
		}catch(Exception e) { 
			e.printStackTrace(); 
		}finally { 
			JDBCUtil.close(pstmt, conn); 
		} 
	}// End insertBoard()======================================================================== 
	// 게시글 삭제 처리 메소드 
	public void deleteBoard(BoardDO boardDO) { 
		System.out.println("===> JDBC로 deleteBoard()처리됨."); 
		try { 
			conn= JDBCUtil.getConnection(); 
			String DELETE_BOARD = "delete from board where seq=?"; 
			pstmt = conn.prepareStatement(DELETE_BOARD); 
			pstmt.setInt(1, boardDO.getSeq()); 
			pstmt.executeUpdate();//dlm 작업 
		}catch(Exception e) { 
			e.printStackTrace(); 
		}finally { 
			JDBCUtil.close(pstmt, conn); 
		} 
	} 
}  
