package com.company.view.user;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.company.spring_annotation.user.UserDAO;
import com.company.spring_annotation.user.UserDO;

@Controller  //Controller를 붙이면 컨테이너가 자동으로 처리 해준다는 의미이다.
public class UserController {
	@RequestMapping("/insertUser.do")  //insertUser.do로 요청이 들어오면
	//어떤 메소드가 처리 할 것인가?
	public String insertUser(UserDO userDO,UserDAO userDAO) { //콘테이너로부터 UserDO의 userDO 객체
		//기존의 방식 MVC/Spring MVC방법에서 10 줄이 생략된다.!!!!
		userDAO.insertUser(userDO);
		return "login.jsp";
	}
}
